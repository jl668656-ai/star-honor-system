// Service Worker for PWA - 离线支持和缓存管理
// v12.x：对“页面导航”采用网络优先，避免更新后仍卡在旧 index.html 导致功能异常（例如登录逻辑不一致）。
const CACHE_NAME = 'honor-system-v12.1';
const FILES_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',
  './firebase-config.js',
  './clear.html'
];

// 安装事件 - 缓存文件
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(FILES_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// 激活事件 - 清理旧缓存
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// 获取事件 - 缓存优先策略（离线友好）
self.addEventListener('fetch', event => {
  // 仅处理 GET 请求
  if (event.request.method !== 'GET') {
    return;
  }

  // 跳过 Firebase 实时数据库请求（需要在线）
  if (event.request.url.includes('firebasedatabase.app')) {
    return;
  }

  const isNavigate = event.request.mode === 'navigate' || event.request.destination === 'document';

  // 页面导航：网络优先（保证更新及时），离线时回退到缓存 index.html
  if (isNavigate) {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put('./index.html', copy)).catch(() => {});
          }
          return response;
        })
        .catch(async () => {
          const cache = await caches.open(CACHE_NAME);
          const cached = await cache.match('./index.html');
          return cached || new Response('离线模式 - 无法访问页面', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: { 'Content-Type': 'text/plain; charset=utf-8' }
          });
        })
    );
    return;
  }

  // 其它资源：缓存优先 + 后台更新
  event.respondWith(
    caches.match(event.request).then(cachedResponse => {
      if (cachedResponse) {
        fetch(event.request).then(response => {
          if (response && response.ok) {
            caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, response);
            });
          }
        }).catch(() => {});
        return cachedResponse;
      }

      return fetch(event.request).then(response => {
        if (response && response.ok) {
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseToCache);
          });
        }
        return response;
      }).catch(() => {
        return new Response('离线模式 - 无法访问此资源', {
          status: 503,
          statusText: 'Service Unavailable',
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      });
    })
  );
});
