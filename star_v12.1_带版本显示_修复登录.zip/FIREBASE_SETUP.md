# 🔥 实时消息推送配置指南

## 功能说明

- **执行者**在手机A上点"我做完了"提交任务
- **管理者**在手机B上立即收到消息弹窗提醒
- **执行者**在手机A上查看审批结果

## 配置步骤

### 1️⃣ 创建 Firebase 项目（免费）

访问：https://console.firebase.google.com/

1. 点 "Create Project"
2. 输入项目名称（如：honor-system）
3. 禁用 Google Analytics，点 Create
4. 等待项目创建完成

### 2️⃣ 创建实时数据库

1. 在左侧菜单找到 "Realtime Database"
2. 点 "Create Database"
3. 选择位置（选离你近的）
4. **重要**：选择 "Start in test mode"（测试模式，方便开发）
5. 点 Enable

### 3️⃣ 获取配置信息

1. 点左上角齿轮 ⚙️ → Project settings
2. 找到你的 Web 应用配置（如果没有则需要添加）
3. 复制以下信息：
   - apiKey
   - authDomain
   - databaseURL
   - projectId
   - storageBucket
   - messagingSenderId
   - appId

### 4️⃣ 更新配置文件

编辑 `firebase-config.js`，替换为你的配置：

```javascript
const firebaseConfig = {
  apiKey: "你的apiKey",
  authDomain: "你的authDomain",
  databaseURL: "你的databaseURL",
  projectId: "你的projectId",
  storageBucket: "你的storageBucket",
  messagingSenderId: "你的messagingSenderId",
  appId: "你的appId"
};
```

### 5️⃣ 在 HTML 中引入配置

在 `index.html` 的 `</body>` 前添加：

```html
<script src="firebase-config.js"></script>
```

## 🚀 使用场景

### 场景1：执行者提交任务

```
手机A (执行者)：
1. 登陆
2. 点"我做完了"
   ↓
Firebase 数据库更新
   ↓
手机B (管理者)：
📣 弹窗："有新任务待审批"
```

### 场景2：管理者审批任务

```
手机B (管理者)：
1. 看到待审批任务
2. 点"通过"或"态度超好"
   ↓
Firebase 数据库更新
   ↓
手机A (执行者)：
📣 弹窗："你的任务已通过！+10⭐"
```

## 📱 在不同网络环境下使用

✅ **同一WiFi 下** - 实时推送（秒级）
✅ **不同网络** - 实时推送（1-2秒延迟）
✅ **离线状态** - 应用本地工作，重新联网后同步

## 🔒 数据库规则（可选）

如果要更严格的安全性，可在 Firebase Console 中修改 Realtime Database 规则：

```json
{
  "rules": {
    "families": {
      ".read": true,
      ".write": true
    }
  }
}
```

（当前是测试模式，所有人都可读写。生产环境需要身份验证）

## ⚙️ 常见问题

**Q: 数据会存储多久？**
A: Firebase 免费版本的 Realtime Database 没有存储时间限制，只要项目存在数据就保留。

**Q: 需要付费吗？**
A: 不需要！免费版本支持：
- 100并发连接
- 1GB 存储空间
- 对家庭使用完全够用

**Q: 能在没有网络时使用吗？**
A: 可以！应用本地使用所有功能，重新连网后会同步到 Firebase。

**Q: 多个孩子怎么办？**
A: 修改 `families/demo-family` 为不同的 room ID 即可：
```javascript
// 第一个孩子
database.ref('families/child-1/pendingTasks')

// 第二个孩子  
database.ref('families/child-2/pendingTasks')
```
